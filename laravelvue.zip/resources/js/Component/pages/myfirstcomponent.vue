<template>
  <div>
      <h1>This is our first page</h1>
  </div>
</template>

<script>
    export default {
        name: "myfirstcomponent"
    }
</script>

<style scoped>


</style>
