<template>

    <h1>I am comA and current state is {{$store.state.counter}}</h1>

</template>

<script>
    export default {
        name: "comA"
    }
</script>

<style scoped>

</style>
