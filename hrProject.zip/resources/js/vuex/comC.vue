<template>
    <h1>I am comC and current state is {{$store.state.counter}}</h1>
</template>

<script>
    export default {
        name: "comC"
    }
</script>

<style scoped>

</style>
