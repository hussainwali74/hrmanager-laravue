<template>
    <h1>I am comB and current state is {{$store.state.counter}}</h1>
</template>

<script>
    export default {
        name: "comB"
    }
</script>

<style scoped>

</style>
