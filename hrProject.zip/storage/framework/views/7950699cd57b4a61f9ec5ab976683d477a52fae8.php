<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script>
            (function () {
                window.laravel={
                    csrfToken:'<?php echo e(csrf_token()); ?>'
                };

            })();

        </script>

        <title>Learning vue with laravel</title>

        <link rel="stylesheet" href="/css/all.css">



        <!-- Fonts -->

    </head>
    <body>

    <div id="app">
        <?php if(Auth::check()): ?>
          <mainapp :user="<?php echo e(Auth::user()); ?>"></mainapp>

        <?php else: ?>
            <mainapp :user="false"></mainapp>

        <?php endif; ?>
    </div>

    </body>

<script src="<?php echo e(mix('/js/app.js')); ?>"></script>
</html>
<?php /**PATH D:\xampp\htdocs\hrProject\resources\views/welcome.blade.php ENDPATH**/ ?>