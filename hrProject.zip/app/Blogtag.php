<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Blogtag extends Model
{
    //
}
